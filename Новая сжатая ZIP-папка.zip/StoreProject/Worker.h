#pragma once
#include "Person.h"
#include "GoodsSize.h"


class Worker : public Person {
private:
	int salary;
	int salarySize;

public:
	Worker(int salarySize) : Person() {
		salary = 0;
		this->salarySize = salarySize;
	}

	void look() {
		Person::look();
		cout << "�������� " << salary << endl;
	}
	void SalaryForLifter(GoodsSize size) {
		if (size == large) {
			salary += 200;
		}
		if (size == little) {
			salary += 100;
		}
	}
	void increaseSalary() {
		salary += salarySize;
	}
};
#pragma once
#include "Goods.h"

class SmallGoods : public Goods {
private:

public:
	SmallGoods() : Goods() {}

	
};
#pragma once

#include "WorkBuilding.h"

class Store : public WorkBuilding {
private:

public:
	Store() : WorkBuilding() {

	}
};
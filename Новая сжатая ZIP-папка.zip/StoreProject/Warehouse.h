#pragma once
#include "WorkBuilding.h"
class Warehouse : public WorkBuilding {
private:

public:
	Warehouse() : WorkBuilding() {
		
	}
};

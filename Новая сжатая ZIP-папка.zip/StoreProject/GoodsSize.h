#pragma once

enum GoodsSize {
	little, large, none
};
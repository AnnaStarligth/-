#pragma once
#include "Goods.h"

class LargeGoods : public Goods {
private:

public:
	LargeGoods() : Goods() {}

	
};